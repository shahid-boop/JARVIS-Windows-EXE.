package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JARVIS Executive HUD palette: deep ink, restrained cyan, premium blue-violet accents.
val JarvisDarkBg = Color(0xFF060A12)
val JarvisDeepNavy = Color(0xFF0A1220)
val JarvisSurfaceCard = Color(0xFF101B2B)
val JarvisSurfaceCardElevated = Color(0xFF17263B)
val JarvisSurfaceGlass = Color(0xCC101B2B)

// Accent hierarchy
val JarvisCyan = Color(0xFF54E8E2)
val JarvisCyanGlow = Color(0xFF8AF4F0)
val JarvisElectricBlue = Color(0xFF5B9DFF)
val JarvisHoloViolet = Color(0xFF9A8CFF)
val JarvisNeonPurple = Color(0xFFB29BFF)

// Semantic states
val JarvisAmberWarning = Color(0xFFFFC56E)
val JarvisRedAlert = Color(0xFFFF6B78)
val JarvisGreenSuccess = Color(0xFF53D6A2)

// Readable typography and subtle dividers
val JarvisTextPrimary = Color(0xFFF1F5FC)
val JarvisTextSecondary = Color(0xFFB0BED1)
val JarvisTextMuted = Color(0xFF7D8CA3)
val JarvisHudBorder = Color(0xFF25344A)
val JarvisHudBorderActive = Color(0x6654E8E2)
