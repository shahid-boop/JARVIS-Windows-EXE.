package com.example.data.service

import com.example.data.model.AtoZFeature
import com.example.data.model.FileItem
import com.example.data.model.PcApp
import com.example.data.model.PcTelemetry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ProcessInfo(
    val pid: Int,
    val name: String,
    val cpuPercent: Float,
    val memoryMb: Int,
    val status: String = "Running"
)

class PcAutomationManager(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()
) {

    private val _telemetry = MutableStateFlow(PcTelemetry())
    val telemetry: StateFlow<PcTelemetry> = _telemetry.asStateFlow()

    private val _runningProcesses = MutableStateFlow<List<ProcessInfo>>(emptyList())
    val runningProcesses: StateFlow<List<ProcessInfo>> = _runningProcesses.asStateFlow()

    private val _recentFiles = MutableStateFlow<List<FileItem>>(emptyList())
    val recentFiles: StateFlow<List<FileItem>> = _recentFiles.asStateFlow()

    private val _systemVolume = MutableStateFlow(50)
    val systemVolume: StateFlow<Int> = _systemVolume.asStateFlow()

    private val _screenBrightness = MutableStateFlow(50)
    val screenBrightness: StateFlow<Int> = _screenBrightness.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private val _isGameModeActive = MutableStateFlow(false)
    val isGameModeActive: StateFlow<Boolean> = _isGameModeActive.asStateFlow()

    private val _screenOcrText = MutableStateFlow("No live screen data yet. Connect to the Windows companion first.")
    val screenOcrText: StateFlow<String> = _screenOcrText.asStateFlow()

    private var bridgeToken: String = ""

    // Complete A to Z PC Automation Feature Suite
    val atozCatalog: List<AtoZFeature> = listOf(
        AtoZFeature('A', "app_launch", "Apps Launcher", "ایپس لانچر", "Apps Kholo", "Launch Chrome, Edge, VS Code, Terminal, Notepad, or Settings", "System", "computer"),
        AtoZFeature('B', "battery_brightness", "Battery & Brightness", "بیٹری اور برائٹنس", "Battery aur Brightness", "Monitor battery level, charging health, and calibrate screen brightness", "Hardware", "battery"),
        AtoZFeature('C', "clipboard_camera", "Clipboard & Camera", "کلپ بورڈ اور کیمرہ", "Clipboard aur Camera", "Read/Write Windows clipboard buffer and toggle webcam privacy guard", "Productivity", "content_copy"),
        AtoZFeature('D', "desktop_display", "Desktop & Display", "ڈیسک ٹاپ مینیجر", "Desktop aur Windows", "Minimize all windows (Win+D), switch virtual desktops, manage multi-monitors", "Desktop", "desktop_windows"),
        AtoZFeature('E', "explorer_extract", "Explorer & Extraction", "فائل ایکسپلورر اور زپ", "File Explorer aur Extract", "Open File Explorer directories and extract ZIP archive contents", "Files", "folder_zip"),
        AtoZFeature('F', "firewall_files", "Firewall & File Search", "فائر وال اور فائل سرچ", "Firewall aur Search", "Verify Windows Defender firewall status and search files by extension", "Security", "security"),
        AtoZFeature('G', "gpu_gaming", "GPU & Game Mode", "گرافکس اور گیم موڈ", "GPU aur Game Mode", "Monitor GPU temperature/load and toggle Windows Ultra Gaming Mode", "Performance", "sports_esports"),
        AtoZFeature('H', "hardware_health", "Hardware & Health", "ہارڈ ویئر صحت", "Hardware Health Check", "Comprehensive audit of CPU, RAM, SSD health, and fan thermal stats", "Diagnostics", "monitor_heart"),
        AtoZFeature('I', "internet_ip", "Internet & IP Diagnostics", "انٹرنیٹ اور آئی پی", "Internet aur IP Config", "Retrieve local IP, gateway, ping latency, and run packet diagnostics", "Network", "wifi"),
        AtoZFeature('J', "jarvis_macro", "JARVIS Dev Preset", "جاروس ڈیو میکرو", "JARVIS Developer Macro", "1-Tap launch developer workspace (VS Code + PowerShell + Chrome + Terminal)", "Productivity", "auto_awesome"),
        AtoZFeature('K', "keyboard_keystrokes", "Keyboard Shortcuts", "کی بورڈ شارٹ کٹس", "Keyboard aur Shortcuts", "Send remote keystrokes (Alt+Tab, Win+Tab, Ctrl+C, Ctrl+V, Esc)", "Automation", "keyboard"),
        AtoZFeature('L', "lock_logoff", "Lock & Logoff", "ورک اسٹیشن لاک", "Lock aur Sign Out", "Securely lock PC workstation, sleep, sign out, or restart with confirmation", "Security", "lock", isDestructive = true),
        AtoZFeature('M', "mouse_media", "Mouse & Media Playback", "میڈیا پلے بیک", "Media Play aur Pause", "Play/Pause music, skip tracks, volume control, and mouse click automation", "Media", "play_circle"),
        AtoZFeature('N', "notification_night", "Notifications & Night Light", "نوٹیفکیشنز اور نائٹ لائٹ", "Notifications aur Night Light", "Send toast alerts to Windows desktop and toggle Night Light blue filter", "System", "notifications"),
        AtoZFeature('O', "ocr_screen", "OCR & Screen Vision", "او سی آر اسکرین ویژن", "Screen OCR aur Reading", "Capture active desktop window and read all visible text and error dialogs", "AI Vision", "document_scanner"),
        AtoZFeature('P', "powershell_cmd", "PowerShell & Terminal", "پاور شیل کنسول", "PowerShell Command Runner", "Execute PowerShell scripts and CMD batch commands with live stdout/stderr", "Terminal", "terminal"),
        AtoZFeature('Q', "quick_toggles", "Quick System Toggles", "فوری سسٹم سیٹنگز", "Quick Settings Toggles", "Toggle Bluetooth, Airplane mode, Focus Assist, and Taskbar auto-hide", "System", "toggle_on"),
        AtoZFeature('R', "recycle_cleanup", "Recycle Bin Cleaner", "ریسائیکل بن کلینر", "Recycle Bin Khali Karo", "Empty Recycle Bin, purge temp files, and reclaim gigabytes of disk space", "Maintenance", "delete_sweep"),
        AtoZFeature('S', "services_startup", "Services & Startup Apps", "اسٹارٹ اپ ایپس مینیجر", "Startup Apps aur Services", "Inspect Windows background services and manage applications that launch on boot", "Performance", "miscellaneous_services"),
        AtoZFeature('T', "task_manager", "Task Manager", "ٹاسک مینیجر", "Task Manager aur Processes", "Detailed live list of running processes with instant kill functionality", "System", "analytics"),
        AtoZFeature('U', "usb_unmount", "USB & External Drives", "یو ایس بی مینیجر", "USB Drives List", "List connected USB flash drives, external SSDs, and safely unmount media", "Hardware", "usb"),
        AtoZFeature('V', "volume_mixer", "Volume & Audio Mixer", "والیوم اور آڈیو مکسر", "Volume aur Audio Mixer", "Adjust master audio level, mute/unmute, and switch default audio outputs", "Audio", "volume_up"),
        AtoZFeature('W', "windows_updates", "Windows Updates & Wi-Fi", "ونڈوز اپ ڈیٹس", "Windows Updates Check", "Check pending Windows updates and scan available Wi-Fi networks", "Maintenance", "sync"),
        AtoZFeature('X', "executable_sandbox", "eXecutable Runner", "اسکرپٹ سینڈ باکس", "Scripts aur Executables", "Safely run custom Python scripts, batch files, and automated test suites", "Development", "code"),
        AtoZFeature('Y', "yield_energy", "Yield Energy (Battery Saver)", "انرجی سیور موڈ", "Battery Saver Mode", "Switch Windows power profile to Low Power / Eco Efficiency mode", "Power", "eco"),
        AtoZFeature('Z', "zip_backup", "ZIP Backup Engine", "زپ بیک اپ انجن", "ZIP Backup Generator", "Instant compressed backup of Desktop and Documents folders with timestamp", "Backup", "archive")
    )

    val availableApps = listOf(
        PcApp("Google Chrome", "chrome.exe", "web", "Browser", isRunning = false),
        PcApp("Microsoft Edge", "msedge.exe", "web", "Browser", isRunning = false),
        PcApp("Visual Studio Code", "code", "terminal", "Development", isRunning = false),
        PcApp("Windows Terminal", "wt.exe", "terminal", "System", isRunning = false),
        PcApp("File Explorer", "explorer.exe", "folder", "System", isRunning = false),
        PcApp("Notepad", "notepad.exe", "notes", "Utility", isRunning = false),
        PcApp("Windows Settings", "ms-settings:", "settings", "System", isRunning = false)
    )

    suspend fun executeAtoZFeature(feature: AtoZFeature): String = withContext(Dispatchers.IO) {
        val ip = _telemetry.value.ipAddress

        when (feature.letter) {
            'A' -> launchApp("Google Chrome")
            'B' -> {
                val requested = if (_screenBrightness.value >= 100) 50 else _screenBrightness.value + 25
                val result = trySendToPcBridge("http://$ip/api/system/brightness", mapOf("brightness" to requested))
                if (result == null) bridgeUnavailable() else { _screenBrightness.value = requested; result }
            }
            'C' -> {
                tryGetFromPcBridge("http://$ip/api/clipboard/read") ?: bridgeUnavailable()
            }
            'D' -> {
                trySendToPcBridge("http://$ip/api/desktop/minimize_all", emptyMap()) ?: bridgeUnavailable()
            }
            'E' -> {
                launchApp("File Explorer")
            }
            'F' -> {
                tryGetFromPcBridge("http://$ip/api/system/firewall") ?: bridgeUnavailable()
            }
            'G' -> {
                tryGetFromPcBridge("http://$ip/api/system/gpu") ?: bridgeUnavailable()
            }
            'H' -> {
                fetchLiveStatus()
            }
            'I' -> {
                tryGetFromPcBridge("http://$ip/api/network/diagnostics") ?: bridgeUnavailable()
            }
            'J' -> {
                val results = listOf(launchApp("Visual Studio Code"), launchApp("Windows Terminal"), launchApp("Google Chrome"))
                results.joinToString("\n")
            }
            'K' -> {
                trySendToPcBridge("http://$ip/api/keyboard/shortcut", mapOf("keys" to "alt+tab")) ?: bridgeUnavailable()
            }
            'L' -> {
                lockWorkstation()
            }
            'M' -> {
                trySendToPcBridge("http://$ip/api/media/toggle", emptyMap()) ?: bridgeUnavailable()
            }
            'N' -> {
                trySendToPcBridge("http://$ip/api/system/notification", mapOf("title" to "JARVIS AI", "msg" to "System operational")) ?: bridgeUnavailable()
            }
            'O' -> {
                scanScreenOcr()
            }
            'P' -> {
                executeTerminalCommand("dir")
            }
            'Q' -> {
                launchApp("Windows Settings")
            }
            'R' -> {
                trySendToPcBridge("http://$ip/api/system/clean_recycle", emptyMap()) ?: bridgeUnavailable()
            }
            'S' -> {
                tryGetFromPcBridge("http://$ip/api/startup") ?: bridgeUnavailable()
            }
            'T' -> {
                fetchProcesses()
            }
            'U' -> {
                tryGetFromPcBridge("http://$ip/api/drives") ?: bridgeUnavailable()
            }
            'V' -> {
                toggleMute()
            }
            'W' -> {
                tryGetFromPcBridge("http://$ip/api/windows/updates") ?: bridgeUnavailable()
            }
            'X' -> {
                executeTerminalCommand("python --version")
            }
            'Y' -> {
                trySendToPcBridge("http://$ip/api/system/power_plan", mapOf("plan" to "power_saver")) ?: bridgeUnavailable()
            }
            'Z' -> {
                trySendToPcBridge("http://$ip/api/files/zip_backup", mapOf("folders" to listOf("Desktop", "Documents"))) ?: bridgeUnavailable()
            }
            else -> "Feature executed."
        }
    }

    suspend fun launchApp(appName: String): String = withContext(Dispatchers.IO) {
        val ip = _telemetry.value.ipAddress
        val result = trySendToPcBridge("http://$ip/api/app/launch", mapOf("app" to appName))
        if (result != null) return@withContext result
        return@withContext bridgeUnavailable()
    }

    suspend fun setVolume(level: Int): String = withContext(Dispatchers.IO) {
        val requested = level.coerceIn(0, 100)
        val result = trySendToPcBridge("http://${_telemetry.value.ipAddress}/api/system/volume", mapOf("volume" to requested))
        if (result == null) return@withContext bridgeUnavailable()
        _systemVolume.value = requested
        _isMuted.value = false
        return@withContext result
    }

    suspend fun toggleMute(): String = withContext(Dispatchers.IO) {
        val requested = !_isMuted.value
        val result = trySendToPcBridge("http://${_telemetry.value.ipAddress}/api/system/mute", mapOf("muted" to requested))
        if (result == null) return@withContext bridgeUnavailable()
        _isMuted.value = requested
        return@withContext result
    }

    suspend fun lockWorkstation(): String = withContext(Dispatchers.IO) {
        val result = trySendToPcBridge("http://${_telemetry.value.ipAddress}/api/system/lock", emptyMap())
        if (result == null) return@withContext bridgeUnavailable()
        _isLocked.value = true
        return@withContext result
    }

    suspend fun unlockWorkstation(): String {
        _isLocked.value = false
        _telemetry.value = _telemetry.value.copy(activeWindow = "Desktop Workspace")
        return "Workstation unlocked."
    }

    suspend fun terminateProcess(pid: Int): String = withContext(Dispatchers.IO) {
        val result = trySendToPcBridge("http://${_telemetry.value.ipAddress}/api/process/kill", mapOf("pid" to pid))
        if (result == null) return@withContext bridgeUnavailable()
        fetchProcesses()
        return@withContext result
    }

    suspend fun executeTerminalCommand(command: String): String = withContext(Dispatchers.IO) {
        val result = trySendToPcBridge("http://${_telemetry.value.ipAddress}/api/terminal/run", mapOf("command" to command))
        return@withContext result ?: bridgeUnavailable()
    }

    suspend fun organizeDownloadsFolder(): String = withContext(Dispatchers.IO) {
        return@withContext trySendToPcBridge(
            "http://${_telemetry.value.ipAddress}/api/files/organize_downloads",
            mapOf("location" to "Downloads")
        ) ?: bridgeUnavailable()
    }

    suspend fun searchPcFiles(query: String, location: String = "Downloads"): String = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext "Enter a file name to search."
        return@withContext trySendToPcBridge(
            "http://${_telemetry.value.ipAddress}/api/files/search",
            mapOf("query" to query.trim().take(120), "location" to location)
        ) ?: bridgeUnavailable()
    }

    suspend fun scanScreenOcr(): String = withContext(Dispatchers.IO) {
        val result = tryGetFromPcBridge("http://${_telemetry.value.ipAddress}/api/screen/ocr")
        if (result == null) return@withContext bridgeUnavailable()
        val text = try { JSONObject(result).optString("text", result) } catch (_: Exception) { result }
        _screenOcrText.value = text
        return@withContext text
    }

    private fun tryGetFromPcBridge(endpoint: String): String? {
        return try {
            val builder = Request.Builder().url(endpoint).get()
            if (bridgeToken.isNotBlank()) builder.header("Authorization", "Bearer $bridgeToken")
            client.newCall(builder.build()).execute().use { res ->
                val body = res.body?.string()
                if (res.isSuccessful) {
                    _telemetry.value = _telemetry.value.copy(connected = true)
                    body
                } else {
                    _telemetry.value = _telemetry.value.copy(connected = false)
                    null
                }
            }
        } catch (_: Exception) {
            _telemetry.value = _telemetry.value.copy(connected = false)
            null
        }
    }

    fun getBridgeTokenForSettings(): String = bridgeToken

    fun updateTelemetry(ip: String, token: String = bridgeToken) {
        val normalized = ip.trim().removePrefix("http://").removePrefix("https://").trimEnd('/')
        _telemetry.value = _telemetry.value.copy(ipAddress = normalized, connected = false)
        bridgeToken = token.trim()
    }

    private fun bridgeUnavailable(): String =
        "PC companion se connection nahi ho saka. PC par server start karein, IP/port aur token check karein. Koi action success mark nahi kiya gaya."

    private fun bridgeNotImplemented(feature: String): String =
        "$feature ka live Windows endpoint abhi companion mein available nahi. Koi simulated result return nahi kiya gaya."

    private fun fetchLiveStatus(): String {
        val result = tryGetFromPcBridge("http://${_telemetry.value.ipAddress}/api/status") ?: return bridgeUnavailable()
        return try {
            val json = JSONObject(result)
            _telemetry.value = _telemetry.value.copy(
                connected = true,
                pcName = json.optString("pc_name", _telemetry.value.pcName),
                cpuUsage = json.optDouble("cpu_percent", 0.0).toInt().coerceIn(0, 100),
                ramUsage = json.optDouble("ram_percent", 0.0).toInt().coerceIn(0, 100),
                batteryPercent = if (json.isNull("battery")) 0 else json.optInt("battery", 0).coerceIn(0, 100)
            )
            result
        } catch (_: Exception) { result }
    }

    private fun fetchProcesses(): String {
        val result = tryGetFromPcBridge("http://${_telemetry.value.ipAddress}/api/processes") ?: return bridgeUnavailable()
        return try {
            val json = JSONObject(result)
            val items = json.optJSONArray("processes") ?: return result
            _runningProcesses.value = (0 until items.length()).mapNotNull { index ->
                val item = items.optJSONObject(index) ?: return@mapNotNull null
                ProcessInfo(item.optInt("pid"), item.optString("name", "unknown"),
                    item.optDouble("cpu_percent", 0.0).toFloat(), item.optInt("memory_mb"))
            }
            result
        } catch (_: Exception) { result }
    }

    private fun trySendToPcBridge(endpoint: String, payload: Map<String, Any>): String? {
        return try {
            val json = JSONObject(payload).toString()
            val builder = Request.Builder()
                .url(endpoint)
                .post(json.toRequestBody("application/json".toMediaType()))
            if (bridgeToken.isNotBlank()) builder.header("Authorization", "Bearer $bridgeToken")
            client.newCall(builder.build()).execute().use { res ->
                val body = res.body?.string()
                if (res.isSuccessful) {
                    _telemetry.value = _telemetry.value.copy(connected = true)
                    body
                } else {
                    _telemetry.value = _telemetry.value.copy(connected = false)
                    null
                }
            }
        } catch (_: Exception) {
            _telemetry.value = _telemetry.value.copy(connected = false)
            null
        }
    }

    fun getPythonServerScript(): String =
        """
        # JARVIS Windows companion. Run on a trusted LAN; configure JARVIS_API_TOKEN.
        import ctypes
        import os
        import re
        import secrets
        import shutil
        import socket
        import subprocess
        import sys
        import zipfile
        from datetime import datetime
        from pathlib import Path
        from typing import Optional

        import psutil
        import uvicorn
        from fastapi import FastAPI, Header, HTTPException, Request
        from fastapi.middleware.cors import CORSMiddleware
        from pydantic import BaseModel, Field

        VERSION = "3.1"
        API_TOKEN = os.getenv("JARVIS_API_TOKEN", "").strip()
        app = FastAPI(title="JARVIS PC Companion Server", version=VERSION)
        # CORS is limited to browser clients; native Android clients are not governed by CORS.
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["http://localhost", "http://127.0.0.1"],
            allow_credentials=False,
            allow_methods=["GET", "POST"],
            allow_headers=["Authorization", "Content-Type"],
        )

        class CommandRequest(BaseModel):
            command: str = Field(min_length=1, max_length=2000)
        class AppRequest(BaseModel):
            app: str = Field(min_length=1, max_length=80)
        class VolumeRequest(BaseModel):
            volume: int = Field(ge=0, le=100)
        class MuteRequest(BaseModel):
            muted: bool
        class BrightnessRequest(BaseModel):
            brightness: int = Field(ge=0, le=100)
        class ShortcutRequest(BaseModel):
            keys: str = Field(min_length=1, max_length=40)
        class NotificationRequest(BaseModel):
            title: str = Field(default="JARVIS", max_length=100)
            msg: str = Field(default="", max_length=500)
        class FileSearchRequest(BaseModel):
            query: str = Field(min_length=1, max_length=120)
            location: str = Field(default="Downloads", max_length=20)
        class OrganizeRequest(BaseModel):
            location: str = Field(default="Downloads", max_length=20)
        class BackupRequest(BaseModel):
            folders: list[str] = Field(default_factory=lambda: ["Desktop", "Documents"], max_length=3)
        class PowerPlanRequest(BaseModel):
            plan: str = Field(pattern="^(balanced|power_saver|high_performance)${'$'}")

        @app.middleware("http")
        async def authenticate(request: Request, call_next):
            if request.url.path not in ("/", "/health") and API_TOKEN:
                supplied = request.headers.get("authorization", "")
                expected = f"Bearer {API_TOKEN}"
                if not secrets.compare_digest(supplied, expected):
                    return __import__("fastapi").responses.JSONResponse(
                        status_code=401, content={"detail": "Missing or invalid JARVIS API token"}
                    )
            return await call_next(request)

        @app.get("/")
        def root():
            return {"status": "online", "service": "JARVIS PC Companion Server", "version": VERSION,
                    "platform": sys.platform, "authentication": bool(API_TOKEN)}

        @app.get("/health")
        def health():
            return {"status": "ok", "version": VERSION}

        @app.get("/api/status")
        def get_telemetry():
            try:
                battery = psutil.sensors_battery()
            except Exception:
                battery = None
            return {"connected": True, "pc_name": os.getenv("COMPUTERNAME", os.getenv("HOSTNAME", "Windows-PC")),
                    "cpu_percent": psutil.cpu_percent(interval=0.2),
                    "ram_percent": psutil.virtual_memory().percent,
                    "battery": battery.percent if battery else None,
                    "is_charging": battery.power_plugged if battery else None, "platform": sys.platform}

        APP_ALLOWLIST = {
            "Google Chrome": ["chrome"], "Microsoft Edge": ["msedge"],
            "Visual Studio Code": ["code"], "Notepad": ["notepad"],
            "File Explorer": ["explorer"], "Windows Terminal": ["wt"],
            "Windows Settings": ["cmd", "/c", "start", "", "ms-settings:"],
        }
        @app.post("/api/app/launch")
        def launch_application(req: AppRequest):
            command = APP_ALLOWLIST.get(req.app)
            if not command:
                raise HTTPException(status_code=400, detail="App is not in the allowed launch list")
            try:
                target = "ms-settings:" if req.app == "Windows Settings" else command[0]
                subprocess.Popen(["cmd", "/c", "start", "", target], shell=False)
                return {"status": "success", "message": f"Launch request sent for {req.app}"}
            except (OSError, subprocess.SubprocessError) as exc:
                raise HTTPException(status_code=500, detail=f"Could not launch app: {exc}")

        @app.get("/api/processes")
        def list_processes():
            result = []
            for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_info"]):
                try:
                    info = proc.info
                    result.append({"pid": info["pid"], "name": info.get("name") or "unknown",
                                   "cpu_percent": info.get("cpu_percent") or 0.0,
                                   "memory_mb": int(info["memory_info"].rss / (1024 * 1024)) if info.get("memory_info") else 0})
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            result.sort(key=lambda item: item["cpu_percent"], reverse=True)
            return {"processes": result[:50]}

        @app.post("/api/process/kill")
        def kill_process(data: dict):
            try:
                pid = int(data.get("pid", 0))
                if pid <= 0:
                    raise HTTPException(status_code=400, detail="A valid PID is required")
                process = psutil.Process(pid)
                # Protect core OS processes from accidental termination.
                if process.pid in (0, 4, os.getpid()):
                    raise HTTPException(status_code=403, detail="Protected process")
                name = process.name()
                process.terminate()
                return {"status": "success", "message": f"Terminate request sent for {name} (PID {pid})"}
            except HTTPException:
                raise
            except psutil.NoSuchProcess:
                raise HTTPException(status_code=404, detail="Process not found")
            except psutil.AccessDenied:
                raise HTTPException(status_code=403, detail="Windows denied permission to terminate this process")

        @app.post("/api/system/lock")
        def lock_workstation():
            if sys.platform != "win32":
                raise HTTPException(status_code=501, detail="Lock workstation is supported only on Windows")
            try:
                ctypes.windll.user32.LockWorkStation()
                return {"status": "success", "message": "Workstation lock requested"}
            except Exception as exc:
                raise HTTPException(status_code=500, detail=str(exc))

        @app.post("/api/system/volume")
        def set_volume(req: VolumeRequest):
            try:
                from pycaw.pycaw import AudioUtilities  # optional Windows dependency
                devices = AudioUtilities.GetSpeakers()
                interface = devices.EndpointVolume
                interface.SetMasterVolumeLevelScalar(req.volume / 100.0, None)
                return {"status": "success", "volume": req.volume}
            except ImportError:
                raise HTTPException(status_code=501, detail="Install pycaw and comtypes to enable volume control")
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Volume control failed: {exc}")

        @app.post("/api/system/mute")
        def set_mute(req: MuteRequest):
            try:
                from pycaw.pycaw import AudioUtilities
                AudioUtilities.GetSpeakers().EndpointVolume.SetMute(1 if req.muted else 0, None)
                return {"status": "success", "muted": req.muted}
            except ImportError:
                raise HTTPException(status_code=501, detail="Install pycaw and comtypes to enable mute control")
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Mute control failed: {exc}")

        @app.post("/api/system/brightness")
        def set_brightness(req: BrightnessRequest):
            try:
                import screen_brightness_control as sbc
                result = sbc.set_brightness(req.brightness)
                return {"status": "success", "brightness": req.brightness, "result": str(result)}
            except ImportError:
                raise HTTPException(status_code=501, detail="Install screen-brightness-control to enable brightness")
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Brightness control failed: {exc}")

        @app.post("/api/desktop/minimize_all")
        def minimize_all():
            if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
            try:
                import pyautogui
                pyautogui.hotkey("win", "d")
                return {"status": "success", "message": "Desktop shown"}
            except Exception as exc: raise HTTPException(status_code=500, detail=str(exc))

        @app.post("/api/keyboard/shortcut")
        def keyboard_shortcut(req: ShortcutRequest):
            allowed = {"alt+tab": ["alt", "tab"], "win+d": ["win", "d"], "ctrl+c": ["ctrl", "c"],
                       "ctrl+v": ["ctrl", "v"], "escape": ["esc"], "ctrl+shift+esc": ["ctrl", "shift", "esc"]}
            keys = allowed.get(req.keys.lower().replace(" ", ""))
            if not keys: raise HTTPException(status_code=400, detail="Shortcut is not in the safe allowlist")
            try:
                import pyautogui
                pyautogui.hotkey(*keys)
                return {"status": "success", "keys": req.keys}
            except Exception as exc: raise HTTPException(status_code=500, detail=str(exc))

        @app.post("/api/media/toggle")
        def media_toggle():
            try:
                import pyautogui
                pyautogui.press("playpause")
                return {"status": "success", "message": "Media play/pause key sent"}
            except Exception as exc: raise HTTPException(status_code=500, detail=str(exc))

        @app.post("/api/system/notification")
        def notification(req: NotificationRequest):
            if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
            # Avoid passing user text through shell interpolation.
            script = "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > ${'$'}null; " \
                     "${'$'}template = [Windows.UI.Notifications.ToastTemplateType]::ToastText02; " \
                     "${'$'}xml = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent(${'$'}template); " \
                     "${'$'}nodes = ${'$'}xml.GetElementsByTagName('text'); ${'$'}nodes.Item(0).AppendChild(${'$'}xml.CreateTextNode(${'$'}args[0])) > ${'$'}null; " \
                     "${'$'}nodes.Item(1).AppendChild(${'$'}xml.CreateTextNode(${'$'}args[1])) > ${'$'}null; " \
                     "${'$'}toast = [Windows.UI.Notifications.ToastNotification]::new(${'$'}xml); " \
                     "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('JARVIS').Show(${'$'}toast)"
            try:
                subprocess.run(["powershell", "-NoProfile", "-Command", script, req.title, req.msg], timeout=10, check=True, capture_output=True)
                return {"status": "success", "message": "Notification sent"}
            except Exception as exc: raise HTTPException(status_code=500, detail=f"Notification failed: {exc}")

        @app.post("/api/system/clean_recycle")
        def clean_recycle():
            if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
            try:
                subprocess.run(["powershell", "-NoProfile", "-Command", "Clear-RecycleBin -Force -ErrorAction Stop"],
                               timeout=30, check=True, capture_output=True, text=True)
                return {"status": "success", "message": "Recycle Bin cleared"}
            except subprocess.CalledProcessError as exc:
                raise HTTPException(status_code=500, detail=exc.stderr or "Recycle Bin cleanup failed")
            except Exception as exc: raise HTTPException(status_code=500, detail=str(exc))

        @app.post("/api/terminal/run")
        def execute_terminal(req: CommandRequest):
            # This endpoint is powerful: keep it behind JARVIS_API_TOKEN on trusted networks.
            try:
                res = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", req.command],
                                     capture_output=True, text=True, timeout=20, shell=False)
                return {"stdout": res.stdout, "stderr": res.stderr, "returncode": res.returncode}
            except subprocess.TimeoutExpired:
                raise HTTPException(status_code=408, detail="Command timed out after 20 seconds")
            except Exception as exc:
                raise HTTPException(status_code=500, detail=str(exc))

        @app.get("/api/screen/ocr")
        def screen_ocr():
            try:
                import pyautogui
                image = pyautogui.screenshot()
                try:
                    import pytesseract
                    return {"text": pytesseract.image_to_string(image), "status": "success"}
                except ImportError:
                    raise HTTPException(status_code=501, detail="Install pytesseract and Tesseract OCR to enable OCR")
            except HTTPException: raise
            except Exception as exc: raise HTTPException(status_code=500, detail=str(exc))



        @app.get("/api/system/firewall")
        def firewall_status():
            if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
            try:
                result = subprocess.run(["powershell", "-NoProfile", "-Command",
                    "Get-NetFirewallProfile | Select-Object Name,Enabled | ConvertTo-Json -Compress"],
                    capture_output=True, text=True, timeout=12, check=True)
                return {"profiles": __import__("json").loads(result.stdout or "[]")}
            except Exception as exc: raise HTTPException(status_code=500, detail=f"Firewall query failed: {exc}")

        @app.get("/api/network/diagnostics")
        def network_diagnostics():
            addresses = []
            for interface, values in psutil.net_if_addrs().items():
                for item in values:
                    if item.family == socket.AF_INET and not item.address.startswith("127."):
                        addresses.append({"interface": interface, "ip": item.address, "netmask": item.netmask})
            stats = psutil.net_io_counters()
            gateway = None
            if sys.platform == "win32":
                try:
                    out = subprocess.run(["powershell", "-NoProfile", "-Command", "(Get-NetRoute -DestinationPrefix '0.0.0.0/0' | Sort-Object RouteMetric | Select-Object -First 1 -ExpandProperty NextHop)"], capture_output=True, text=True, timeout=8)
                    gateway = out.stdout.strip() or None
                except Exception: pass
            return {"hostname": socket.gethostname(), "addresses": addresses, "gateway": gateway,
                    "bytes_sent": stats.bytes_sent, "bytes_received": stats.bytes_recv,
                    "interfaces": [{"name": k, "is_up": v.isup, "speed_mbps": v.speed} for k,v in psutil.net_if_stats().items()]}

        @app.get("/api/startup")
        def startup_items():
            if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
            script = "Get-CimInstance Win32_StartupCommand | Select-Object Name,Command,Location,User | ConvertTo-Json -Compress"
            try:
                out = subprocess.run(["powershell", "-NoProfile", "-Command", script], capture_output=True, text=True, timeout=15, check=True)
                data = __import__("json").loads(out.stdout or "[]")
                return {"items": data if isinstance(data, list) else ([data] if data else [])}
            except Exception as exc: raise HTTPException(status_code=500, detail=f"Startup inventory failed: {exc}")

        @app.get("/api/drives")
        def drive_inventory():
            drives = []
            for part in psutil.disk_partitions(all=False):
                try:
                    usage = psutil.disk_usage(part.mountpoint)
                    drives.append({"device": part.device, "mountpoint": part.mountpoint, "filesystem": part.fstype,
                                   "total_gb": round(usage.total / 1e9, 2), "free_gb": round(usage.free / 1e9, 2),
                                   "used_percent": usage.percent})
                except (PermissionError, OSError): continue
            removable = []
            if sys.platform == "win32":
                try:
                    out = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=2' | Select-Object DeviceID,VolumeName,Size,FreeSpace | ConvertTo-Json -Compress"], capture_output=True, text=True, timeout=10)
                    raw = __import__("json").loads(out.stdout or "[]")
                    removable = raw if isinstance(raw, list) else ([raw] if raw else [])
                except Exception: pass
            return {"drives": drives, "removable": removable}

        @app.get("/api/windows/updates")
        def windows_updates():
            if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
            try:
                out = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 20 HotFixID,Description,InstalledOn,InstalledBy | ConvertTo-Json -Compress"], capture_output=True, text=True, timeout=15, check=True)
                raw = __import__("json").loads(out.stdout or "[]")
                return {"recent_installed_updates": raw if isinstance(raw, list) else ([raw] if raw else []), "note": "Recent installed hotfixes; this is not a pending-update scan."}
            except Exception as exc: raise HTTPException(status_code=500, detail=f"Update inventory failed: {exc}")

        @app.get("/api/system/gpu")
        def gpu_inventory():
            if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
            try:
                out = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,AdapterRAM,VideoModeDescription | ConvertTo-Json -Compress"], capture_output=True, text=True, timeout=12, check=True)
                raw = __import__("json").loads(out.stdout or "[]")
                return {"gpus": raw if isinstance(raw, list) else ([raw] if raw else [])}
            except Exception as exc: raise HTTPException(status_code=500, detail=f"GPU inventory failed: {exc}")

        @app.get("/api/system/power_plan")
        def get_power_plan():
            if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
            try:
                out = subprocess.run(["powercfg", "/getactivescheme"], capture_output=True, text=True, timeout=8, check=True)
                return {"active_plan": out.stdout.strip()}
            except Exception as exc: raise HTTPException(status_code=500, detail=f"Power plan query failed: {exc}")

        @app.post("/api/system/power_plan")
        def set_power_plan(req: PowerPlanRequest):
            if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
            plans = {"balanced":"381b4222-f694-41f0-9685-ff5bb260df2e", "power_saver":"a1841308-3541-4fab-bc81-f71556f20b4a", "high_performance":"8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"}
            try:
                subprocess.run(["powercfg", "/setactive", plans[req.plan]], capture_output=True, text=True, timeout=10, check=True)
                return {"status":"success", "plan":req.plan}
            except subprocess.CalledProcessError as exc: raise HTTPException(status_code=500, detail=exc.stderr or "Could not change power plan")

        _ALLOWED_LOCATIONS = {"Desktop": Path.home()/"Desktop", "Documents": Path.home()/"Documents", "Downloads": Path.home()/"Downloads"}
        def _safe_location(name: str) -> Path:
            if name not in _ALLOWED_LOCATIONS: raise HTTPException(status_code=400, detail="Location must be Desktop, Documents, or Downloads")
            path = _ALLOWED_LOCATIONS[name]
            if not path.exists() or not path.is_dir(): raise HTTPException(status_code=404, detail=f"Folder not found: {name}")
            return path

        @app.post("/api/files/search")
        def search_files(req: FileSearchRequest):
            base = _safe_location(req.location)
            query = req.query.casefold()
            matches = []
            try:
                for path in base.rglob("*"):
                    if len(matches) >= 250: break
                    if path.is_file() and query in path.name.casefold():
                        try: matches.append({"name":path.name, "path":str(path), "size_bytes":path.stat().st_size, "modified":datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds")})
                        except OSError: continue
            except (PermissionError, OSError): pass
            return {"location":req.location, "count":len(matches), "matches":matches, "truncated":len(matches)>=250}

        @app.post("/api/files/organize_downloads")
        def organize_downloads(req: OrganizeRequest):
            base = _safe_location(req.location)
            categories = {"Images":{ ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg"},
                          "Documents":{".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".xls", ".xlsx", ".ppt", ".pptx", ".csv"},
                          "Archives":{".zip", ".7z", ".rar", ".tar", ".gz"},
                          "Audio":{".mp3", ".wav", ".flac", ".m4a", ".aac"},
                          "Video":{".mp4", ".mkv", ".mov", ".avi", ".webm"},
                          "Installers":{".exe", ".msi", ".apk"}}
            moved = 0; errors = []
            for path in list(base.iterdir()):
                if not path.is_file(): continue
                target_name = next((name for name, exts in categories.items() if path.suffix.lower() in exts), None)
                if not target_name: continue
                folder = base / target_name
                try:
                    folder.mkdir(exist_ok=True)
                    dest = folder / path.name
                    if dest.exists(): dest = folder / f"{path.stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}{path.suffix}"
                    shutil.move(str(path), str(dest)); moved += 1
                except OSError as exc: errors.append(f"{path.name}: {exc}")
            return {"status":"success" if not errors else "partial", "moved":moved, "errors":errors[:20], "location":str(base)}

        @app.post("/api/files/zip_backup")
        def create_zip_backup(req: BackupRequest):
            allowed = {"Desktop", "Documents"}
            if not req.folders or any(name not in allowed for name in req.folders):
                raise HTTPException(status_code=400, detail="Backup accepts Desktop and/or Documents only")
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            out_dir = Path.home()/"JARVIS_Backups"; out_dir.mkdir(exist_ok=True)
            target = out_dir/f"jarvis_backup_{stamp}.zip"
            added = 0; errors = []
            try:
                with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
                    for name in req.folders:
                        source = Path.home()/name
                        if not source.is_dir(): errors.append(f"{name} folder not found"); continue
                        for file in source.rglob("*"):
                            if not file.is_file(): continue
                            try:
                                archive.write(file, str(Path(name)/file.relative_to(source))); added += 1
                            except (PermissionError, OSError): errors.append(f"Skipped unreadable file: {file.name}")
                if added == 0:
                    target.unlink(missing_ok=True)
                    raise HTTPException(status_code=404, detail="No files could be added to backup")
                return {"status":"success", "path":str(target), "files_added":added, "errors":errors[:20]}
            except HTTPException: raise
            except Exception as exc: raise HTTPException(status_code=500, detail=f"Backup failed: {exc}")

        @app.get("/api/clipboard/read")
        def read_clipboard():
            if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
            try:
                import pyperclip
                return {"text":pyperclip.paste(), "status":"success"}
            except ImportError: raise HTTPException(status_code=501, detail="Install pyperclip to enable clipboard read")
            except Exception as exc: raise HTTPException(status_code=500, detail=f"Clipboard read failed: {exc}")


        if __name__ == "__main__":
            port = int(os.getenv("PORT", "8765"))
            host = os.getenv("JARVIS_HOST", "0.0.0.0")
            if not API_TOKEN and host not in ("127.0.0.1", "localhost", "::1"):
                raise SystemExit("Refusing LAN startup without JARVIS_API_TOKEN. Set a strong token or bind to localhost only.")
            print("JARVIS API token authentication is enabled." if API_TOKEN else "Loopback-only development mode.")
            print(f"JARVIS PC Companion Server {VERSION} starting on {host}:{port}")
            uvicorn.run(app, host=host, port=port)
        """.trimIndent()

}
