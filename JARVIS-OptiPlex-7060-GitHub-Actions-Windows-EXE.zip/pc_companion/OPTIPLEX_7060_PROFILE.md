# JARVIS profile: Dell OptiPlex 7060

This profile is tuned for the user-provided target hardware:

- Dell OptiPlex 7060
- Intel Core i7-8700 (6 cores / 12 threads)
- 16 GB RAM (8 GB + 8 GB)
- Intel integrated graphics; exact adapter/driver should be confirmed by the diagnostic script
- 128 GB + 500 GB SSDs

## Recommended operating profile

- **Everyday use:** Windows Balanced power plan; one local model/inference job at a time.
- **Local AI:** begin with a 1B–4B quantized model. A 7B/8B Q4 model is an optional experiment and may be slow or memory-constrained; measure it before regular use. Urdu/Roman Urdu quality depends on the model, not just hardware.
- **Graphics:** Intel integrated graphics generally shares system RAM. Do not assume dedicated 4 GB VRAM or CUDA. Start with CPU inference; test Intel/OpenVINO/DirectML acceleration only after confirming the exact adapter, driver and model runtime.
- **Context:** begin around 4K tokens for local inference and raise only if memory and responsiveness remain stable.
- **RAM:** preserve at least 4 GB for Windows, browser and JARVIS. Avoid running multiple local models simultaneously.
- **Storage:** keep at least 20 GB free on the 128 GB system SSD. Put model files, caches and backups on the 500 GB SSD if it is a separate usable volume. Confirm drive letters before configuring paths.
- **Thermals:** check CPU temperatures and cooling before sustained high-performance workloads. Do not change BIOS/voltage settings automatically.

## Live diagnostic endpoint

After starting the Windows companion, request `GET /api/system/optimization` with the configured bearer token. It returns the target profile, actual detected CPU/RAM/GPU/drive inventory, and recommendations. This endpoint is read-only; it does not modify Windows settings.

## Safety and limitations

The exact Intel graphics adapter, driver, supported acceleration backend, SSD drive letters, and current free space must be detected on the actual PC. Integrated graphics memory reporting varies by Windows/driver; it is not a reliable reason to assume a fixed dedicated VRAM pool. These recommendations are conservative starting points, not benchmark results.
