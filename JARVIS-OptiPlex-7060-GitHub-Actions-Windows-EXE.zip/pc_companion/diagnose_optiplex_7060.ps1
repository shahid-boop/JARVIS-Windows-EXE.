# Read-only diagnostics for the JARVIS OptiPlex 7060 profile.
# No settings are changed and no data is deleted.
$ErrorActionPreference = 'Continue'
Write-Host '=== JARVIS / OptiPlex 7060 hardware diagnostic (read-only) ===' -ForegroundColor Cyan
Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer, Model, TotalPhysicalMemory | Format-List
Get-CimInstance Win32_Processor | Select-Object Name, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed | Format-List
Get-CimInstance Win32_VideoController | Select-Object Name, DriverVersion, AdapterRAM, VideoModeDescription | Format-List
Get-CimInstance Win32_PhysicalMemory | Select-Object Manufacturer, Capacity, Speed, PartNumber | Format-Table -AutoSize
Get-PhysicalDisk | Select-Object FriendlyName, MediaType, BusType, Size, HealthStatus | Format-Table -AutoSize
Get-Volume | Where-Object DriveLetter | Select-Object DriveLetter, FileSystemLabel, FileSystem, Size, SizeRemaining, HealthStatus | Format-Table -AutoSize
Write-Host '--- Active power plan ---' -ForegroundColor Cyan
powercfg /getactivescheme
Write-Host '--- Free RAM ---' -ForegroundColor Cyan
Get-CimInstance Win32_OperatingSystem | Select-Object @{N='FreeRAM_GB';E={[math]::Round($_.FreePhysicalMemory/1MB,1)}}, @{N='TotalRAM_GB';E={[math]::Round($_.TotalVisibleMemorySize/1MB,1)}} | Format-List
Write-Host 'Diagnostic complete. No Windows settings were changed.' -ForegroundColor Green
