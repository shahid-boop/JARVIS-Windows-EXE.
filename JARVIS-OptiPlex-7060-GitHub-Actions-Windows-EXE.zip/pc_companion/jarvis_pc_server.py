"""JARVIS Windows companion. Run on a trusted LAN; configure JARVIS_API_TOKEN."""
import ctypes
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional

import psutil
import uvicorn
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

VERSION = "3.1"
API_TOKEN = os.getenv("JARVIS_API_TOKEN", "").strip()
app = FastAPI(title="JARVIS PC Companion Server", version=VERSION)
# CORS is limited to browser clients; native Android clients are not governed by CORS.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost", "http://127.0.0.1"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Authorization", "Content-Type"],
)

class CommandRequest(BaseModel):
    command: str = Field(min_length=1, max_length=2000)
class AppRequest(BaseModel):
    app: str = Field(min_length=1, max_length=80)
class VolumeRequest(BaseModel):
    volume: int = Field(ge=0, le=100)
class MuteRequest(BaseModel):
    muted: bool
class BrightnessRequest(BaseModel):
    brightness: int = Field(ge=0, le=100)
class ShortcutRequest(BaseModel):
    keys: str = Field(min_length=1, max_length=40)
class NotificationRequest(BaseModel):
    title: str = Field(default="JARVIS", max_length=100)
    msg: str = Field(default="", max_length=500)
class FileSearchRequest(BaseModel):
    query: str = Field(min_length=1, max_length=120)
    location: str = Field(default="Downloads", max_length=20)
class OrganizeRequest(BaseModel):
    location: str = Field(default="Downloads", max_length=20)
class BackupRequest(BaseModel):
    folders: list[str] = Field(default_factory=lambda: ["Desktop", "Documents"], max_length=3)
class PowerPlanRequest(BaseModel):
    plan: str = Field(pattern="^(balanced|power_saver|high_performance)$")

@app.middleware("http")
async def authenticate(request: Request, call_next):
    if request.url.path not in ("/", "/health") and API_TOKEN:
        supplied = request.headers.get("authorization", "")
        expected = f"Bearer {API_TOKEN}"
        if not secrets.compare_digest(supplied, expected):
            return __import__("fastapi").responses.JSONResponse(
                status_code=401, content={"detail": "Missing or invalid JARVIS API token"}
            )
    return await call_next(request)

@app.get("/")
def root():
    return {"status": "online", "service": "JARVIS PC Companion Server", "version": VERSION,
            "platform": sys.platform, "authentication": bool(API_TOKEN)}

@app.get("/health")
def health():
    return {"status": "ok", "version": VERSION}

@app.get("/api/status")
def get_telemetry():
    try:
        battery = psutil.sensors_battery()
    except Exception:
        battery = None
    return {"connected": True, "pc_name": os.getenv("COMPUTERNAME", os.getenv("HOSTNAME", "Windows-PC")),
            "cpu_percent": psutil.cpu_percent(interval=0.2),
            "ram_percent": psutil.virtual_memory().percent,
            "battery": battery.percent if battery else None,
            "is_charging": battery.power_plugged if battery else None, "platform": sys.platform}

APP_ALLOWLIST = {
    "Google Chrome": ["chrome"], "Microsoft Edge": ["msedge"],
    "Visual Studio Code": ["code"], "Notepad": ["notepad"],
    "File Explorer": ["explorer"], "Windows Terminal": ["wt"],
    "Windows Settings": ["cmd", "/c", "start", "", "ms-settings:"],
}
@app.post("/api/app/launch")
def launch_application(req: AppRequest):
    command = APP_ALLOWLIST.get(req.app)
    if not command:
        raise HTTPException(status_code=400, detail="App is not in the allowed launch list")
    try:
        target = "ms-settings:" if req.app == "Windows Settings" else command[0]
        subprocess.Popen(["cmd", "/c", "start", "", target], shell=False)
        return {"status": "success", "message": f"Launch request sent for {req.app}"}
    except (OSError, subprocess.SubprocessError) as exc:
        raise HTTPException(status_code=500, detail=f"Could not launch app: {exc}")

@app.get("/api/processes")
def list_processes():
    result = []
    for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_info"]):
        try:
            info = proc.info
            result.append({"pid": info["pid"], "name": info.get("name") or "unknown",
                           "cpu_percent": info.get("cpu_percent") or 0.0,
                           "memory_mb": int(info["memory_info"].rss / (1024 * 1024)) if info.get("memory_info") else 0})
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    result.sort(key=lambda item: item["cpu_percent"], reverse=True)
    return {"processes": result[:50]}

@app.post("/api/process/kill")
def kill_process(data: dict):
    try:
        pid = int(data.get("pid", 0))
        if pid <= 0:
            raise HTTPException(status_code=400, detail="A valid PID is required")
        process = psutil.Process(pid)
        # Protect core OS processes from accidental termination.
        if process.pid in (0, 4, os.getpid()):
            raise HTTPException(status_code=403, detail="Protected process")
        name = process.name()
        process.terminate()
        return {"status": "success", "message": f"Terminate request sent for {name} (PID {pid})"}
    except HTTPException:
        raise
    except psutil.NoSuchProcess:
        raise HTTPException(status_code=404, detail="Process not found")
    except psutil.AccessDenied:
        raise HTTPException(status_code=403, detail="Windows denied permission to terminate this process")

@app.post("/api/system/lock")
def lock_workstation():
    if sys.platform != "win32":
        raise HTTPException(status_code=501, detail="Lock workstation is supported only on Windows")
    try:
        ctypes.windll.user32.LockWorkStation()
        return {"status": "success", "message": "Workstation lock requested"}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@app.post("/api/system/volume")
def set_volume(req: VolumeRequest):
    try:
        from pycaw.pycaw import AudioUtilities  # optional Windows dependency
        devices = AudioUtilities.GetSpeakers()
        interface = devices.EndpointVolume
        interface.SetMasterVolumeLevelScalar(req.volume / 100.0, None)
        return {"status": "success", "volume": req.volume}
    except ImportError:
        raise HTTPException(status_code=501, detail="Install pycaw and comtypes to enable volume control")
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Volume control failed: {exc}")

@app.post("/api/system/mute")
def set_mute(req: MuteRequest):
    try:
        from pycaw.pycaw import AudioUtilities
        AudioUtilities.GetSpeakers().EndpointVolume.SetMute(1 if req.muted else 0, None)
        return {"status": "success", "muted": req.muted}
    except ImportError:
        raise HTTPException(status_code=501, detail="Install pycaw and comtypes to enable mute control")
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Mute control failed: {exc}")

@app.post("/api/system/brightness")
def set_brightness(req: BrightnessRequest):
    try:
        import screen_brightness_control as sbc
        result = sbc.set_brightness(req.brightness)
        return {"status": "success", "brightness": req.brightness, "result": str(result)}
    except ImportError:
        raise HTTPException(status_code=501, detail="Install screen-brightness-control to enable brightness")
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Brightness control failed: {exc}")

@app.post("/api/desktop/minimize_all")
def minimize_all():
    if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
    try:
        import pyautogui
        pyautogui.hotkey("win", "d")
        return {"status": "success", "message": "Desktop shown"}
    except Exception as exc: raise HTTPException(status_code=500, detail=str(exc))

@app.post("/api/keyboard/shortcut")
def keyboard_shortcut(req: ShortcutRequest):
    allowed = {"alt+tab": ["alt", "tab"], "win+d": ["win", "d"], "ctrl+c": ["ctrl", "c"],
               "ctrl+v": ["ctrl", "v"], "escape": ["esc"], "ctrl+shift+esc": ["ctrl", "shift", "esc"]}
    keys = allowed.get(req.keys.lower().replace(" ", ""))
    if not keys: raise HTTPException(status_code=400, detail="Shortcut is not in the safe allowlist")
    try:
        import pyautogui
        pyautogui.hotkey(*keys)
        return {"status": "success", "keys": req.keys}
    except Exception as exc: raise HTTPException(status_code=500, detail=str(exc))

@app.post("/api/media/toggle")
def media_toggle():
    try:
        import pyautogui
        pyautogui.press("playpause")
        return {"status": "success", "message": "Media play/pause key sent"}
    except Exception as exc: raise HTTPException(status_code=500, detail=str(exc))

@app.post("/api/system/notification")
def notification(req: NotificationRequest):
    if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
    # Avoid passing user text through shell interpolation.
    script = "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null; " \
             "$template = [Windows.UI.Notifications.ToastTemplateType]::ToastText02; " \
             "$xml = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent($template); " \
             "$nodes = $xml.GetElementsByTagName('text'); $nodes.Item(0).AppendChild($xml.CreateTextNode($args[0])) > $null; " \
             "$nodes.Item(1).AppendChild($xml.CreateTextNode($args[1])) > $null; " \
             "$toast = [Windows.UI.Notifications.ToastNotification]::new($xml); " \
             "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('JARVIS').Show($toast)"
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", script, req.title, req.msg], timeout=10, check=True, capture_output=True)
        return {"status": "success", "message": "Notification sent"}
    except Exception as exc: raise HTTPException(status_code=500, detail=f"Notification failed: {exc}")

@app.post("/api/system/clean_recycle")
def clean_recycle():
    if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
    try:
        subprocess.run(["powershell", "-NoProfile", "-Command", "Clear-RecycleBin -Force -ErrorAction Stop"],
                       timeout=30, check=True, capture_output=True, text=True)
        return {"status": "success", "message": "Recycle Bin cleared"}
    except subprocess.CalledProcessError as exc:
        raise HTTPException(status_code=500, detail=exc.stderr or "Recycle Bin cleanup failed")
    except Exception as exc: raise HTTPException(status_code=500, detail=str(exc))

@app.post("/api/terminal/run")
def execute_terminal(req: CommandRequest):
    # This endpoint is powerful: keep it behind JARVIS_API_TOKEN on trusted networks.
    try:
        res = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", req.command],
                             capture_output=True, text=True, timeout=20, shell=False)
        return {"stdout": res.stdout, "stderr": res.stderr, "returncode": res.returncode}
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=408, detail="Command timed out after 20 seconds")
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))

@app.get("/api/screen/ocr")
def screen_ocr():
    try:
        import pyautogui
        image = pyautogui.screenshot()
        try:
            import pytesseract
            return {"text": pytesseract.image_to_string(image), "status": "success"}
        except ImportError:
            raise HTTPException(status_code=501, detail="Install pytesseract and Tesseract OCR to enable OCR")
    except HTTPException: raise
    except Exception as exc: raise HTTPException(status_code=500, detail=str(exc))



@app.get("/api/system/firewall")
def firewall_status():
    if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
    try:
        result = subprocess.run(["powershell", "-NoProfile", "-Command",
            "Get-NetFirewallProfile | Select-Object Name,Enabled | ConvertTo-Json -Compress"],
            capture_output=True, text=True, timeout=12, check=True)
        return {"profiles": __import__("json").loads(result.stdout or "[]")}
    except Exception as exc: raise HTTPException(status_code=500, detail=f"Firewall query failed: {exc}")

@app.get("/api/network/diagnostics")
def network_diagnostics():
    addresses = []
    for interface, values in psutil.net_if_addrs().items():
        for item in values:
            if item.family == socket.AF_INET and not item.address.startswith("127."):
                addresses.append({"interface": interface, "ip": item.address, "netmask": item.netmask})
    stats = psutil.net_io_counters()
    gateway = None
    if sys.platform == "win32":
        try:
            out = subprocess.run(["powershell", "-NoProfile", "-Command", "(Get-NetRoute -DestinationPrefix '0.0.0.0/0' | Sort-Object RouteMetric | Select-Object -First 1 -ExpandProperty NextHop)"], capture_output=True, text=True, timeout=8)
            gateway = out.stdout.strip() or None
        except Exception: pass
    return {"hostname": socket.gethostname(), "addresses": addresses, "gateway": gateway,
            "bytes_sent": stats.bytes_sent, "bytes_received": stats.bytes_recv,
            "interfaces": [{"name": k, "is_up": v.isup, "speed_mbps": v.speed} for k,v in psutil.net_if_stats().items()]}

@app.get("/api/startup")
def startup_items():
    if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
    script = "Get-CimInstance Win32_StartupCommand | Select-Object Name,Command,Location,User | ConvertTo-Json -Compress"
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", script], capture_output=True, text=True, timeout=15, check=True)
        data = __import__("json").loads(out.stdout or "[]")
        return {"items": data if isinstance(data, list) else ([data] if data else [])}
    except Exception as exc: raise HTTPException(status_code=500, detail=f"Startup inventory failed: {exc}")

@app.get("/api/drives")
def drive_inventory():
    drives = []
    for part in psutil.disk_partitions(all=False):
        try:
            usage = psutil.disk_usage(part.mountpoint)
            drives.append({"device": part.device, "mountpoint": part.mountpoint, "filesystem": part.fstype,
                           "total_gb": round(usage.total / 1e9, 2), "free_gb": round(usage.free / 1e9, 2),
                           "used_percent": usage.percent})
        except (PermissionError, OSError): continue
    removable = []
    if sys.platform == "win32":
        try:
            out = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=2' | Select-Object DeviceID,VolumeName,Size,FreeSpace | ConvertTo-Json -Compress"], capture_output=True, text=True, timeout=10)
            raw = __import__("json").loads(out.stdout or "[]")
            removable = raw if isinstance(raw, list) else ([raw] if raw else [])
        except Exception: pass
    return {"drives": drives, "removable": removable}

@app.get("/api/windows/updates")
def windows_updates():
    if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 20 HotFixID,Description,InstalledOn,InstalledBy | ConvertTo-Json -Compress"], capture_output=True, text=True, timeout=15, check=True)
        raw = __import__("json").loads(out.stdout or "[]")
        return {"recent_installed_updates": raw if isinstance(raw, list) else ([raw] if raw else []), "note": "Recent installed hotfixes; this is not a pending-update scan."}
    except Exception as exc: raise HTTPException(status_code=500, detail=f"Update inventory failed: {exc}")

@app.get("/api/system/gpu")
def gpu_inventory():
    if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,AdapterRAM,VideoModeDescription | ConvertTo-Json -Compress"], capture_output=True, text=True, timeout=12, check=True)
        raw = __import__("json").loads(out.stdout or "[]")
        return {"gpus": raw if isinstance(raw, list) else ([raw] if raw else [])}
    except Exception as exc: raise HTTPException(status_code=500, detail=f"GPU inventory failed: {exc}")

@app.get("/api/system/power_plan")
def get_power_plan():
    if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
    try:
        out = subprocess.run(["powercfg", "/getactivescheme"], capture_output=True, text=True, timeout=8, check=True)
        return {"active_plan": out.stdout.strip()}
    except Exception as exc: raise HTTPException(status_code=500, detail=f"Power plan query failed: {exc}")

@app.post("/api/system/power_plan")
def set_power_plan(req: PowerPlanRequest):
    if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
    plans = {"balanced":"381b4222-f694-41f0-9685-ff5bb260df2e", "power_saver":"a1841308-3541-4fab-bc81-f71556f20b4a", "high_performance":"8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"}
    try:
        subprocess.run(["powercfg", "/setactive", plans[req.plan]], capture_output=True, text=True, timeout=10, check=True)
        return {"status":"success", "plan":req.plan}
    except subprocess.CalledProcessError as exc: raise HTTPException(status_code=500, detail=exc.stderr or "Could not change power plan")

_ALLOWED_LOCATIONS = {"Desktop": Path.home()/"Desktop", "Documents": Path.home()/"Documents", "Downloads": Path.home()/"Downloads"}
def _safe_location(name: str) -> Path:
    if name not in _ALLOWED_LOCATIONS: raise HTTPException(status_code=400, detail="Location must be Desktop, Documents, or Downloads")
    path = _ALLOWED_LOCATIONS[name]
    if not path.exists() or not path.is_dir(): raise HTTPException(status_code=404, detail=f"Folder not found: {name}")
    return path

@app.post("/api/files/search")
def search_files(req: FileSearchRequest):
    base = _safe_location(req.location)
    query = req.query.casefold()
    matches = []
    try:
        for path in base.rglob("*"):
            if len(matches) >= 250: break
            if path.is_file() and query in path.name.casefold():
                try: matches.append({"name":path.name, "path":str(path), "size_bytes":path.stat().st_size, "modified":datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds")})
                except OSError: continue
    except (PermissionError, OSError): pass
    return {"location":req.location, "count":len(matches), "matches":matches, "truncated":len(matches)>=250}

@app.post("/api/files/organize_downloads")
def organize_downloads(req: OrganizeRequest):
    base = _safe_location(req.location)
    categories = {"Images":{ ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg"},
                  "Documents":{".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".xls", ".xlsx", ".ppt", ".pptx", ".csv"},
                  "Archives":{".zip", ".7z", ".rar", ".tar", ".gz"},
                  "Audio":{".mp3", ".wav", ".flac", ".m4a", ".aac"},
                  "Video":{".mp4", ".mkv", ".mov", ".avi", ".webm"},
                  "Installers":{".exe", ".msi", ".apk"}}
    moved = 0; errors = []
    for path in list(base.iterdir()):
        if not path.is_file(): continue
        target_name = next((name for name, exts in categories.items() if path.suffix.lower() in exts), None)
        if not target_name: continue
        folder = base / target_name
        try:
            folder.mkdir(exist_ok=True)
            dest = folder / path.name
            if dest.exists(): dest = folder / f"{path.stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}{path.suffix}"
            shutil.move(str(path), str(dest)); moved += 1
        except OSError as exc: errors.append(f"{path.name}: {exc}")
    return {"status":"success" if not errors else "partial", "moved":moved, "errors":errors[:20], "location":str(base)}

@app.post("/api/files/zip_backup")
def create_zip_backup(req: BackupRequest):
    allowed = {"Desktop", "Documents"}
    if not req.folders or any(name not in allowed for name in req.folders):
        raise HTTPException(status_code=400, detail="Backup accepts Desktop and/or Documents only")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path.home()/"JARVIS_Backups"; out_dir.mkdir(exist_ok=True)
    target = out_dir/f"jarvis_backup_{stamp}.zip"
    added = 0; errors = []
    try:
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for name in req.folders:
                source = Path.home()/name
                if not source.is_dir(): errors.append(f"{name} folder not found"); continue
                for file in source.rglob("*"):
                    if not file.is_file(): continue
                    try:
                        archive.write(file, str(Path(name)/file.relative_to(source))); added += 1
                    except (PermissionError, OSError): errors.append(f"Skipped unreadable file: {file.name}")
        if added == 0:
            target.unlink(missing_ok=True)
            raise HTTPException(status_code=404, detail="No files could be added to backup")
        return {"status":"success", "path":str(target), "files_added":added, "errors":errors[:20]}
    except HTTPException: raise
    except Exception as exc: raise HTTPException(status_code=500, detail=f"Backup failed: {exc}")

@app.get("/api/clipboard/read")
def read_clipboard():
    if sys.platform != "win32": raise HTTPException(status_code=501, detail="Windows only")
    try:
        import pyperclip
        return {"text":pyperclip.paste(), "status":"success"}
    except ImportError: raise HTTPException(status_code=501, detail="Install pyperclip to enable clipboard read")
    except Exception as exc: raise HTTPException(status_code=500, detail=f"Clipboard read failed: {exc}")


@app.get("/api/system/optimization")
def system_optimization_profile():
    """Read-only, resource-aware recommendations for the OptiPlex 7060 target PC."""
    vm = psutil.virtual_memory()
    cpu_logical = psutil.cpu_count(logical=True) or 12
    cpu_physical = psutil.cpu_count(logical=False) or 6
    disks = []
    for part in psutil.disk_partitions(all=False):
        # Skip inaccessible and optical/removable paths; report only mounted fixed disks.
        if "cdrom" in (part.opts or "").lower():
            continue
        try:
            usage = psutil.disk_usage(part.mountpoint)
            disks.append({
                "mountpoint": part.mountpoint,
                "filesystem": part.fstype,
                "total_gb": round(usage.total / (1024 ** 3), 1),
                "free_gb": round(usage.free / (1024 ** 3), 1),
                "used_percent": usage.percent,
            })
        except (PermissionError, OSError):
            continue

    cpu_name = None
    gpu_names = []
    if sys.platform == "win32":
        try:
            result = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command",
                 "Get-CimInstance Win32_Processor | Select-Object -First 1 -ExpandProperty Name"],
                capture_output=True, text=True, timeout=8, check=True,
            )
            cpu_name = result.stdout.strip() or None
        except Exception:
            pass
        try:
            result = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command",
                 "Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name"],
                capture_output=True, text=True, timeout=8, check=True,
            )
            gpu_names = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        except Exception:
            pass

    # Target hardware: i7-8700, 16 GB RAM, Intel integrated graphics, 128+500 GB SSDs.
    # Integrated graphics generally share system RAM; do not invent a dedicated VRAM size.
    recommendations = [
        {"area": "AI inference", "setting": "Start with a 1B–4B quantized model; treat 7B/8B as an optional CPU-heavy experiment, not a guaranteed smooth workload.", "reason": "The PC has 16 GB system RAM and Intel integrated graphics with shared memory, so available RAM must be measured at runtime."},
        {"area": "GPU acceleration", "setting": "Start with CPU inference. Enable Intel/OpenVINO/DirectML acceleration only after confirming the exact GPU, driver, model runtime and a successful benchmark.", "reason": "Intel integrated graphics does not imply CUDA support or a dedicated 4 GB VRAM pool."},
        {"area": "Concurrency", "setting": "One local model inference at a time; start with a 4K context window.", "reason": "Reduces RAM/VRAM pressure and avoids sluggish multitasking."},
        {"area": "CPU", "setting": f"Use up to {cpu_logical} logical threads for CPU-bound jobs, but start at {min(cpu_logical, 6)} threads for interactive inference.", "reason": "Keeps desktop responsiveness on the 6-core/12-thread target CPU."},
        {"area": "Memory", "setting": "Keep at least 4 GB RAM free for Windows and foreground apps; close unused browser tabs before local inference.", "reason": "Prevents paging and stalls on a 16 GB system."},
        {"area": "Storage", "setting": "Keep Windows and paging on the 128 GB SSD with at least 20 GB free; store models, caches and backups on the 500 GB SSD when available.", "reason": "Protects OS update headroom and reduces contention on the smaller drive."},
        {"area": "Power", "setting": "Use Balanced for daily use; enable High Performance only for plugged-in, sustained workloads after checking thermals.", "reason": "Avoids unnecessary heat/noise and power draw."},
    ]
    return {
        "status": "success",
        "profile_id": "optiplex-7060-i7-8700-16gb-intel-igpu",
        "profile_target": {"model": "Dell OptiPlex 7060", "cpu": "Intel Core i7-8700 (6 cores / 12 threads)", "ram_gb": 16, "gpu_type": "Intel integrated graphics (shared system memory; exact model/driver detected at runtime)", "dedicated_vram_gb": None, "storage_target": ["128 GB SSD", "500 GB SSD"]},
        "detected": {"pc_name": os.getenv("COMPUTERNAME", os.getenv("HOSTNAME", "Windows-PC")), "cpu_name": cpu_name, "physical_cores": cpu_physical, "logical_threads": cpu_logical, "ram_total_gb": round(vm.total / (1024 ** 3), 1), "ram_available_gb": round(vm.available / (1024 ** 3), 1), "gpu_names": gpu_names, "drives": disks},
        "recommendations": recommendations,
        "notes": ["Target specifications are user-provided; live detected values may differ.", "Intel integrated graphics generally shares system RAM; dedicated VRAM is not assumed.", "This endpoint is read-only and does not change Windows settings."],
    }


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8765"))
    host = os.getenv("JARVIS_HOST", "0.0.0.0")
    if not API_TOKEN and host not in ("127.0.0.1", "localhost", "::1"):
        raise SystemExit("Refusing LAN startup without JARVIS_API_TOKEN. Set a strong token or bind to localhost only.")
    print("JARVIS API token authentication is enabled." if API_TOKEN else "Loopback-only development mode.")
    print(f"JARVIS PC Companion Server {VERSION} starting on {host}:{port}")
    uvicorn.run(app, host=host, port=port)
