# GitHub Actions: Windows EXE build

This project includes `.github/workflows/build-windows-exe.yml`. Upload/extract the ZIP contents into the root of your GitHub repository `shahid-boop/JARVIS-Professional-Pakistani-Edition`, keeping the `.github` folder. Commit and push to `main` (or `master`), or open **Actions → Build JARVIS Windows EXE → Run workflow**.

When the workflow finishes successfully, open that run, scroll to **Artifacts**, and download `JARVIS-Professional-Windows-EXE`. The artifact contains `JARVIS-Professional.exe`, start-up instructions, and the PC companion notes.

**Important:** this workflow builds the Python Windows PC companion/server as a standalone EXE. It does not turn the Android APK into a Windows desktop app. The Android app remains an Android project and is built separately as an APK. The EXE has not been produced until GitHub Actions completes successfully.

For LAN use, set a strong `JARVIS_API_TOKEN` in PowerShell before starting the EXE. Keep the PC companion on a trusted private network and do not expose its port directly to the internet.
