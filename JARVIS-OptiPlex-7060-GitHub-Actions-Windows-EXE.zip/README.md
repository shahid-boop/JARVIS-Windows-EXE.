<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/ae53a1c5-f05c-44ed-b03e-0108a4b5adb2

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.


## JARVIS Companion v3 upgrade notes

The existing Android screens and source modules are retained. PC telemetry/process views no longer start with invented sample process/file/CPU values; actions report bridge errors instead of pretending they succeeded. The Windows companion now includes endpoints for status, process listing/termination, allowlisted app launch, workstation lock, volume/mute (optional pycaw), brightness (optional screen-brightness-control), desktop minimize, allowlisted keyboard shortcuts, media toggle, notifications, recycle-bin cleanup, terminal execution, and optional OCR. Unsupported A-Z features explicitly report that the endpoint is not implemented rather than returning fake success.

### Windows companion setup

1. Install Python 3.10+ on the Windows PC.
2. In `pc_companion`, run `python -m pip install -r requirements.txt`.
3. Set a strong shared token before exposing the server on your LAN, for example in PowerShell: `$env:JARVIS_API_TOKEN = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))`. Copy that same token into the Android Settings screen.
4. Start it with `python jarvis_pc_server.py`. Allow port 8765 through Windows Firewall only for your trusted private network.
5. In the app, enter the PC's LAN IP and port (for example `192.168.1.20:8765`) and the same API token.

The terminal endpoint can execute PowerShell commands, so do not run the server on a public/untrusted network. Authentication is enforced whenever `JARVIS_API_TOKEN` is configured; without it, the server prints a warning. Volume, brightness, and OCR need their optional Windows packages and compatible hardware.


## JARVIS PRO upgrade (source-preserving)

This upgrade keeps the original project files and adds practical Windows companion APIs for network diagnostics, firewall profile status, startup inventory, drive inventory, GPU inventory, recent installed Windows hotfixes, power-plan control, file search, Downloads organization, Desktop/Documents ZIP backup, and clipboard reading. The A–Z Android actions now call these endpoints instead of returning placeholder messages where an endpoint is available.

### Security and limits
- Set a long random `JARVIS_API_TOKEN` before exposing the companion to your local network. The server refuses LAN startup without a token.
- Do not forward the companion port to the public internet. PowerShell execution is privileged remote administration and must only be used on a trusted network.
- File search is limited to Desktop, Documents, and Downloads. ZIP backup accepts Desktop/Documents only. Downloads organization moves files into extension-based folders and should be run only when you want that change.
- Windows-only features require Windows; optional controls may need the packages in `pc_companion/requirements.txt`. GPU temperatures, pending Windows Update discovery, Bluetooth/airplane toggles, and some hardware telemetry are not guaranteed across every Windows PC.
- Android build and live phone-to-Windows end-to-end tests must still be run in an Android/Windows environment before production use.

### OptiPlex 7060 hardware tuning

A read-only hardware optimization endpoint is available at `GET /api/system/optimization`. It reports live detected CPU/RAM/GPU/drives and conservative recommendations for the target Dell OptiPlex 7060 (i7-8700, 16 GB RAM, Intel integrated graphics, 128+500 GB SSD). Integrated graphics generally shares system RAM; dedicated 4 GB VRAM is not assumed. See `pc_companion/OPTIPLEX_7060_PROFILE.md`. Run `powershell -ExecutionPolicy Bypass -File .\diagnose_optiplex_7060.ps1` for a read-only hardware report. It does not change system settings. Since the exact GPU model is unspecified, JARVIS does not assume CUDA/DirectML support.
