# JARVIS PC Assistant — Functional Audit & Completion Plan

**Audit date:** 2026-10-19  
**Target:** Windows PC + Android app  
**Hardware supplied:** Dell OptiPlex 7060, Intel Core i7-8700 (6 cores/12 threads), 16 GB RAM, Intel integrated graphics, 128 GB + 500 GB SSDs.  
**Scope:** Static source review plus limited automated checks in the available development environment. This is not a claim that every feature was tested on the user's PC or phone.

## Executive verdict

The project is a useful prototype/source base with a Compose Android UI, Room persistence, a voice interface, an AI provider router, a Windows FastAPI companion and several real Windows endpoints. It is **not yet production-ready or fully end-to-end verified**.

### Checks actually performed in this audit

- Python syntax compilation for `pc_companion/jarvis_pc_server.py`: **PASS**.
- FastAPI `GET /health`: **HTTP 200 PASS**.
- FastAPI `GET /api/system/optimization`: **HTTP 200 PASS**; profile fields inspected.
- Android Gradle build/unit tests: **NOT RUN**. This archive has `gradle/wrapper/gradle-wrapper.properties` but no `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`; no system `gradle` or Android SDK was available in the audit environment.
- Real Windows actions, Android installation, LAN pairing, AI provider API calls, and microphone/TTS behaviour: **NOT RUN on target devices**.

## Classification key

- **Code present / targeted check passed:** source path exists and a limited test of that exact part passed; not a blanket guarantee.
- **Implemented in source, runtime unverified:** implementation exists but has not been tested on the user's Windows PC/Android phone.
- **Incomplete:** UI or basic path exists, but the advertised capability is only partial or lacks a real executor.
- **Demo-only / misleading success:** hard-coded sample output, simulation, or success state can be shown without verifying the real operation.
- **Untested:** no live target-device or provider test has been performed.

## Feature audit

| Area | Classification | Evidence / finding | Required completion |
|---|---|---|---|
| Android app structure and Compose screens | Code present / untested build | `MainActivity.kt`, HUD, Voice Chat, PC Control, Brain Router, Coding Studio, Files, Workflow, Memory/Audit and Settings screens exist. | Restore a reproducible Gradle wrapper/build environment; compile debug APK and run tests on device/emulator. |
| Room chat, memory and audit database | Implemented in source, runtime unverified | Room entities/DAOs exist for messages, memory and audit logs. | Test fresh install, schema migration, restart persistence, clear-history and concurrent writes. |
| AI provider router | Implemented in source, runtime unverified | `AiBrainRouter.kt` contains Gemini, Groq, OpenRouter, Ollama, OpenAI and Claude request paths plus offline fallback. | Test each provider with valid/invalid keys, HTTP errors, timeouts, rate limits, model-ID changes and no-network mode. Confirm fallback reason is visible rather than silently pretending an online response was produced. |
| Offline conversation | Demo-only for general reasoning | Offline branch uses keyword-based canned replies; it is not a local neural model or general-purpose local LLM. | Label it as command/FAQ fallback, or connect a real local inference runtime and prove offline model loading. |
| Natural-language PC actions | Demo-only / incomplete | `AiBrainRouter.kt` has hard-coded claims such as battery at 92%, brightness set to 75%, clipboard content, recycle-bin space reclaimed, screenshot OCR done, and ZIP backup created. These responses are returned by parsing, not by Windows confirmation. | Route every action to the companion, check the actual HTTP result, read back state when possible, and report success only after verification. |
| Action status/audit logging | Incorrect success semantics | `MainViewModel.kt` records A–Z and several actions as `success`/`Executed` regardless of the actual result string; generic actions can fall through to `success`. | Use typed outcomes (`success`, `partial`, `failed`, `blocked`, `cancelled`, `unavailable`) and base logs/voice messages on the real executor result. |
| Voice input | Implemented in source, runtime unverified | Android `SpeechRecognizer` listens on request and uses `ur-PK` or `en-US`. It depends on Android speech service/device settings. | Test permission denied, no speech service, network/offline speech, Urdu and Roman Urdu recognition, cancellation and error recovery. |
| Text-to-speech | Implemented in source, runtime unverified | Android TTS is used; Urdu voice falls back to English if Urdu voice data is unavailable. | Detect and surface voice-data/locale fallback; test pronunciation, interruption, lifecycle and audio focus. |
| Voice waveform | Demo-only visualization | `JarvisVoiceEngine.kt` creates simulated amplitudes with random/noise/sine values. It is not a raw microphone/audio waveform. | Either label it as an animation or derive visualizer values from actual RMS/audio output. |
| Wake word / hands-free always listening | Incomplete / not verified | The inspected voice engine starts speech recognition on explicit request; no confirmed always-on wake-word service was found in the reviewed path. | Add a permission-aware, battery-conscious foreground service and real wake-word detector only if this is a required feature. |
| Windows companion API | Implemented in source, runtime unverified | FastAPI endpoints cover status, launch allowlist, processes/termination, lock, volume/mute, brightness, minimize, shortcuts, media, notification, recycle bin, terminal, OCR, firewall, network diagnostics, startup list, drives, recent hotfixes, GPU inventory, power plan, file search/organize/ZIP backup, clipboard and optimization profile. | Run endpoint tests on Windows 10/11, including missing optional dependencies, non-admin mode, permissions, unavailable devices and API errors. |
| Android ↔ Windows connection | Incomplete / untested | Android sends HTTP to configured PC address and bearer token; live connection was not tested. HTTP cleartext is enabled in the manifest. | Test LAN IP/port, token, firewall, reconnect, timeout, stale IP, phone/PC on separate networks and safe error display. Prefer TLS or tightly constrained trusted-LAN operation. |
| Authentication | Security issue to fix before LAN use | Middleware only rejects requests when `JARVIS_API_TOKEN` is non-empty. The startup guard protects direct script startup, but ASGI import/run modes can bypass that `__main__` guard and leave protected routes unauthenticated if the environment token is empty. `/` and `/health` are intentionally public. | Enforce auth for every non-public route at middleware level; fail closed when binding to a non-loopback address; test all startup modes. Rotate token if it has ever been shared. |
| Remote PowerShell endpoint | High-risk design requiring guardrails | `/api/terminal/run` executes a caller-supplied PowerShell command. A token alone is not a command sandbox. | Default-disable or use a strict command allowlist, per-action confirmation, timeouts/output limits, audit records and private-network firewall restrictions. Never expose port 8765 publicly. |
| A–Z PC feature catalogue | Incomplete / misleading descriptions | A–Z list contains ambitious descriptions that exceed the current handler. Examples: Q opens Windows Settings rather than toggling quick settings; X only runs `python --version`; U lists drives but does not safely unmount; G returns GPU inventory but not temperature/game mode; W lists recent installed hotfixes, not pending updates; E launches Explorer but does not extract ZIPs. | Create a feature-to-endpoint matrix; implement each feature or mark it unavailable/partial in the UI without removing catalogue entries. |
| Windows updates | Partial | `/api/windows/updates` explicitly returns recent installed hotfixes and says it is not a pending-update scan. | Rename UI label or implement a proper pending-update query with supported Windows APIs. |
| Files search / Downloads organizer / ZIP backup | Implemented in source, runtime unverified | These are real filesystem operations constrained to selected known folders; organizer moves files, backup writes under `~/JARVIS_Backups`. | Add preview/dry-run, collision and rollback tests, symlink/reparse-point handling, cancellation, size limits, backup verification and clear confirmation before moving files. |
| Screen OCR | Implemented in source, runtime unverified | Screenshot + `pytesseract` path exists; it requires Tesseract installation and a working desktop session. | Verify Tesseract binary/path, headless/session errors, DPI/multi-monitor behaviour and privacy prompt before capture. |
| Coding Studio | Incomplete / demo-only generation | `CodingStudioEngine.kt` seeds a static calculator project. `runTestsAndBuild()` explicitly reports `NOT BUILT / NOT TESTED`; it does not run code or package artifacts. New project generation uses templates rather than an AI code call in the inspected method. | Connect real AI generation and an isolated execution/build sandbox; use temporary workspaces, resource limits, dependency allowlist and artifact verification. Never report tests/build success unless the process exit code and outputs confirm it. |
| Workflow engine | Incomplete (explicitly blocked) | `WorkflowEngine.kt` pauses the first step because no real tool executor is configured. | Implement registered executors per tool, real progress/result contracts, cancellation, retries, idempotency and persisted run history. Keep blocked status truthful. |
| PC telemetry and state | Partially implemented | Live status and process endpoints exist; some UI state defaults (volume, brightness, mute/lock) are local estimates and do not necessarily mirror Windows until a readback API is added. | Add actual getters/readback and label unknown/stale values as unknown instead of treating defaults as live state. |
| Intel integrated graphics optimization | Target profile corrected in this archive | Intel integrated graphics generally shares system RAM; a dedicated 4 GB VRAM pool must not be assumed. Exact adapter and driver need live detection. | Start with CPU inference and small quantized models; benchmark an Intel-compatible backend only after exact GPU/driver/runtime detection. |
| Packaging / reproducible Android build | Blocker | Gradle wrapper properties exist, but wrapper scripts/JAR are absent from this ZIP; Android build could not be run here. | Add the official Gradle wrapper files for the configured Gradle version (or document a tested Android Studio import flow), then run clean build and tests. |

## Security and correctness priorities

### P0 — Fix before using remote PC control on a LAN

1. Require authentication on every non-public endpoint even if the server is launched through an ASGI server rather than `python jarvis_pc_server.py`.
2. Fail closed if a non-loopback host is selected without a strong token; document that `/` and `/health` reveal only minimal service health.
3. Restrict or disable arbitrary PowerShell execution by default. A bearer token does not make arbitrary command execution safe.
4. Do not port-forward the server; restrict Windows Firewall to the private LAN and trusted phone.
5. Correct the action status pipeline so failed/unavailable commands never produce a success voice line or success audit entry.

### P1 — Establish reproducible build and tests

1. Restore Gradle wrapper files and record the supported JDK/Gradle/Android Gradle Plugin versions.
2. Build debug APK; run unit, Robolectric and instrumentation tests.
3. Add unit tests for every action mapping and for failed bridge responses; add Python API tests for auth, validation, non-Windows responses and filesystem safety.
4. Add API contract tests so Android endpoint paths and Python route definitions cannot drift.

### P2 — Complete real integrations

1. Connect each advertised A–Z feature to a real endpoint or label it partial/unavailable; do not delete features.
2. Add live state readbacks for volume, brightness, mute, power plan and connection health.
3. Validate every AI provider and Ollama fallback; surface key/model/network errors.
4. Add proper local-model runtime selection; do not call the keyword fallback a local neural model.
5. Connect Coding Studio to a real, isolated runner and workflows to real executors.

### P3 — Voice, usability and reliability

1. Test Urdu and English STT/TTS across device configurations.
2. Decide whether the waveform is decorative or data-driven; clearly label it.
3. Implement wake-word listening only with explicit permission, foreground-service notification and battery testing.
4. Add structured error messages, cancellation, retry/backoff and reconnect behaviour.
5. Verify backup/organize previews and undo/recovery paths.

### P4 — Hardware tuning and performance

1. Run `diagnose_optiplex_7060.ps1` on the actual PC and save the report.
2. Confirm Windows version, exact Intel adapter/driver, RAM availability, drive letters/free space and optional OCR/audio dependencies.
3. Benchmark 1B–4B quantized models first; measure tokens/sec, peak RAM, responsiveness and temperature. Try larger models only if measured results justify it.
4. Test CPU inference first; enable Intel GPU acceleration only after successful backend-specific verification.

## Minimum acceptance test matrix

- [ ] Clean Android debug build succeeds from the documented setup.
- [ ] Unit + Robolectric + instrumentation tests pass.
- [ ] App launches and survives process death/restart without losing persisted chat/memory unexpectedly.
- [ ] Android connects to Windows with a valid token and rejects missing/invalid tokens.
- [ ] No-token server startup on a LAN is refused in every supported launch mode.
- [ ] Chrome/Notepad/Explorer launch returns truthful success/failure.
- [ ] Volume/mute/brightness commands are read back from Windows and match requested state where supported.
- [ ] Process list/termination protects critical processes and reports access-denied outcomes.
- [ ] PowerShell endpoint cannot run arbitrary commands unless explicitly enabled under a safe policy.
- [ ] File search, organizer dry-run/commit, ZIP backup and backup integrity tests pass on disposable test folders.
- [ ] OCR works when Tesseract is installed and returns a clear actionable error when it is not.
- [ ] Each AI provider passes success, bad-key, rate-limit, timeout and no-network tests.
- [ ] Offline mode is accurately labelled and never claims live PC data it did not retrieve.
- [ ] Voice recognition, TTS, interruption, permission denial and unsupported Urdu voice are handled truthfully.
- [ ] Coding Studio never reports build/test success without a real runner result.
- [ ] Workflow status remains blocked until a real executor is connected and tested.
- [ ] Intel graphics/local-model benchmark is documented with exact adapter/driver, model, quantization, context and measured performance.

## Preservation rule

This plan is additive. It does not call for removing any existing source file, screen, feature catalogue entry or resource. Implementations should be corrected in place, with new tests, adapters, documentation and explicit status reporting added alongside existing functionality.
